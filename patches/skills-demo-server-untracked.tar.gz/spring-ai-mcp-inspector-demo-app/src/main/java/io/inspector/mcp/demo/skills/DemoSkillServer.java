package io.inspector.mcp.demo.skills;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;

import com.sun.net.httpserver.HttpExchange;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.node.ArrayNode;
import tools.jackson.databind.node.ObjectNode;
import com.sun.net.httpserver.HttpServer;

/**
 * A minimal HTTP server that speaks the MCP Streamable HTTP transport and implements the
 * SEP-2640 skills extension. Serves static skill files from {@link SkillStorage} and
 * handles JSON-RPC methods ({@code initialize}, {@code skills/list}, {@code skills/get},
 * {@code resources/read}, {@code resources/directory/read}) on the bare protocol level.
 * <p>
 * The server runs on a configurable port (default 8082) and accepts JSON-RPC POST
 * requests at its root path. It is designed to be started by
 * {@link DemoSkillServerAutoConfiguration} as a Spring {@code @Bean}.
 */
public final class DemoSkillServer {

	private static final String VERSION = "2.0.1";

	private static final String PROTOCOL_VERSION = "2025-11-25";

	private final HttpServer httpServer;

	private final SkillStorage storage;

	private final ObjectMapper mapper;

	private final int port;

	DemoSkillServer(final int port) {
		this.port = port;
		this.storage = new SkillStorage();
		this.mapper = new ObjectMapper();
		try {
			this.httpServer = HttpServer.create(new InetSocketAddress(port), 0);
			this.httpServer.createContext("/", this::handleRequest);
			this.httpServer.setExecutor(Executors.newFixedThreadPool(4));
		}
		catch (final IOException e) {
			throw new RuntimeException("Failed to start SEP-2640 demo server on port " + port, e);
		}
	}

	void start() {
		this.httpServer.start();
	}

	void stop() {
		this.httpServer.stop(1);
	}

	/** Standalone entry point for testing. Starts on port 8082 and blocks forever. */
	public static void main(final String[] args) throws InterruptedException {
		final int port = (args.length > 0) ? Integer.parseInt(args[0]) : 8082;
		final DemoSkillServer server = new DemoSkillServer(port);
		server.start();
		Thread.currentThread().join();
	}

	int port() {
		return this.port;
	}

	private void handleRequest(final HttpExchange exchange) throws IOException {
		try {
			if (!"POST".equals(exchange.getRequestMethod())) {
				sendError(exchange, 405, "Method Not Allowed");
				return;
			}
			final byte[] body = readAll(exchange.getRequestBody());
			final ObjectNode request = (ObjectNode) this.mapper.readTree(body);
			final ObjectNode response = handleJsonRpc(request);
			if (response != null) {
				final byte[] respBytes = this.mapper.writerWithDefaultPrettyPrinter().writeValueAsBytes(response);
				exchange.getResponseHeaders().set("Content-Type", "application/json");
				exchange.sendResponseHeaders(200, respBytes.length);
				exchange.getResponseBody().write(respBytes);
			}
			else {
				// Notification: no response body required
				exchange.sendResponseHeaders(200, -1);
			}
		}
		catch (final Exception e) {
			sendError(exchange, 500, "Internal Server Error: " + e.getMessage());
		}
		finally {
			exchange.close();
		}
	}

	private ObjectNode handleJsonRpc(final ObjectNode request) {
		final String method = request.has("method") ? request.get("method").asText() : "";
		final JsonNode params = request.get("params");
		final JsonNode id = request.get("id");

		try {
			return switch (method) {
				case "initialize" -> handleInitialize(id);
				case "ping" -> result(id, mapper.createObjectNode());
				case "skills/list" -> handleSkillsList(id);
				case "skills/get" -> handleSkillsGet(id, params);
				case "resources/read" -> handleResourcesRead(id, params);
				case "resources/directory/read" -> handleDirectoryRead(id, params);
				case "notifications/initialized", "notifications/roots/list_changed" -> null; // no
																								// response
																								// for
																								// notifications
				default -> error(id, -32601, "Method not found: " + method);
			};
		}
		catch (final Exception e) {
			return error(id, -32603, "Internal error: " + e.getMessage());
		}
	}

	private ObjectNode handleInitialize(final JsonNode id) {
		final ObjectNode result = mapper.createObjectNode();
		result.put("protocolVersion", PROTOCOL_VERSION);

		final ObjectNode capabilities = mapper.createObjectNode();

		// Extensions declaration per SEP-2640
		final ObjectNode extensions = mapper.createObjectNode();
		final ObjectNode skillsExt = mapper.createObjectNode();
		skillsExt.put("directoryRead", true);
		extensions.set("io.modelcontextprotocol/skills", skillsExt);
		capabilities.set("extensions", extensions);

		// Standard capabilities
		final ObjectNode resources = mapper.createObjectNode();
		resources.put("listChanged", false);
		resources.put("subscribe", false);
		capabilities.set("resources", resources);

		result.set("capabilities", capabilities);

		final ObjectNode serverInfo = mapper.createObjectNode();
		serverInfo.put("name", "mcp-inspector-demo-skills");
		serverInfo.put("version", VERSION);
		result.set("serverInfo", serverInfo);
		return result(id, result);
	}

	private ObjectNode handleSkillsList(final JsonNode id) {
		final List<SkillStorage.SkillEntry> skills = this.storage.listSkills();
		final ArrayNode skillsArray = mapper.createArrayNode();
		for (final SkillStorage.SkillEntry entry : skills) {
			skillsArray.add(buildSkillEntry(entry));
		}
		final ObjectNode result = mapper.createObjectNode();
		result.put("resultType", "complete");
		result.set("skills", skillsArray);
		return result(id, result);
	}

	private ObjectNode handleSkillsGet(final JsonNode id, final JsonNode params) {
		if (params == null || !params.has("uri")) {
			return error(id, -32602, "Missing required parameter 'uri'");
		}
		final String uri = params.get("uri").asText();
		final SkillStorage.SkillEntry entry = this.storage.getSkill(uri);
		if (entry == null) {
			return error(id, -32602, "Skill not found: " + uri);
		}
		final ObjectNode result = mapper.createObjectNode();
		result.put("resultType", "complete");
		result.set("skill", buildSkillEntry(entry));
		return result(id, result);
	}

	private ObjectNode handleResourcesRead(final JsonNode id, final JsonNode params) {
		if (params == null || !params.has("uri")) {
			return error(id, -32602, "Missing required parameter 'uri'");
		}
		final String uri = params.get("uri").asText();
		final byte[] content = this.storage.content(uri);
		if (content == null) {
			return error(id, -32602, "Resource not found: " + uri);
		}

		final ObjectNode result = mapper.createObjectNode();
		final ArrayNode contents = mapper.createArrayNode();
		final ObjectNode item = mapper.createObjectNode();
		item.put("uri", uri);
		item.put("mimeType", this.storage.mimeType(uri));
		item.put("text", new String(content, StandardCharsets.UTF_8));
		contents.add(item);
		result.set("contents", contents);
		return result(id, result);
	}

	private ObjectNode handleDirectoryRead(final JsonNode id, final JsonNode params) {
		if (params == null || !params.has("uri")) {
			return error(id, -32602, "Missing required parameter 'uri'");
		}
		final String uri = params.get("uri").asText();
		final List<Map<String, Object>> children = this.storage.directoryListing(uri);
		if (children == null || children.isEmpty()) {
			// Check if the directory itself exists
			if (!uri.startsWith("skill://")) {
				return error(id, -32602, "Not a directory: " + uri);
			}
		}
		final ObjectNode result = mapper.createObjectNode();
		final ArrayNode resources = mapper.createArrayNode();
		for (final Map<String, Object> child : children) {
			final ObjectNode childNode = mapper.createObjectNode();
			childNode.put("uri", (String) child.get("uri"));
			childNode.put("name", (String) child.get("name"));
			childNode.put("mimeType", (String) child.get("mimeType"));
			resources.add(childNode);
		}
		result.set("resources", resources);
		return result(id, result);
	}

	private ObjectNode buildSkillEntry(final SkillStorage.SkillEntry entry) {
		final ObjectNode node = mapper.createObjectNode();
		node.put("uri", entry.uri);
		final ObjectNode fm = mapper.createObjectNode();
		entry.frontmatter.forEach((key, value) -> fm.set(key, mapper.valueToTree(value)));
		node.set("frontmatter", fm);

		final ArrayNode resources = mapper.createArrayNode();
		for (final SkillStorage.SkillFile file : entry.files) {
			final ObjectNode fileNode = mapper.createObjectNode();
			fileNode.put("uri", file.uri);
			fileNode.put("digest", file.digest);
			fileNode.put("size", file.size);
			resources.add(fileNode);
		}
		node.set("resources", resources);
		return node;
	}

	private ObjectNode result(final JsonNode id, final ObjectNode resultPayload) {
		final ObjectNode resp = mapper.createObjectNode();
		resp.put("jsonrpc", "2.0");
		resp.set("id", id);
		resp.set("result", resultPayload);
		return resp;
	}

	private ObjectNode error(final JsonNode id, final int code, final String message) {
		final ObjectNode resp = mapper.createObjectNode();
		resp.put("jsonrpc", "2.0");
		resp.set("id", id);
		final ObjectNode err = mapper.createObjectNode();
		err.put("code", code);
		err.put("message", message);
		resp.set("error", err);
		return resp;
	}

	private static void sendError(final HttpExchange exchange, final int code, final String message)
			throws IOException {
		final byte[] bytes = message.getBytes(StandardCharsets.UTF_8);
		exchange.sendResponseHeaders(code, bytes.length);
		exchange.getResponseBody().write(bytes);
	}

	private static byte[] readAll(final InputStream in) throws IOException {
		final ByteArrayOutputStream out = new ByteArrayOutputStream();
		final byte[] buf = new byte[4096];
		int n;
		while ((n = in.read(buf)) != -1) {
			out.write(buf, 0, n);
		}
		return out.toByteArray();
	}

}