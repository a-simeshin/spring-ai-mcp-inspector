package io.inspector.mcp.demo.skills;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import tools.jackson.dataformat.yaml.YAMLMapper;

/**
 * Manages the skill directory tree loaded from the classpath. Computes SHA-256 digests
 * and file sizes for every shipped file so the server can advertise correct digests
 * without reading files on every request.
 */
final class SkillStorage {

	static final class SkillFile {

		final String uri;

		final String digest;

		final long size;

		SkillFile(final String uri, final String digest, final long size) {
			this.uri = uri;
			this.digest = digest;
			this.size = size;
		}

	}

	static final class SkillEntry {

		final String name;

		final String uri;

		final Map<String, Object> frontmatter;

		final List<SkillFile> files;

		SkillEntry(final String name, final String uri, final Map<String, Object> frontmatter,
				final List<SkillFile> files) {
			this.name = name;
			this.uri = uri;
			this.frontmatter = frontmatter;
			this.files = files;
		}

	}

	private final List<SkillEntry> skills;

	private final Map<String, SkillEntry> byName;

	private final Map<String, byte[]> contentByUri;

	private final Map<String, String> mimeByUri;

	SkillStorage() {
		this.skills = new ArrayList<>();
		this.byName = new LinkedHashMap<>();
		this.contentByUri = new LinkedHashMap<>();
		this.mimeByUri = new LinkedHashMap<>();
		loadSkills();
	}

	List<SkillEntry> listSkills() {
		return this.skills;
	}

	SkillEntry getSkill(final String uri) {
		return this.byName.get(uri);
	}

	SkillEntry forUri(final String uri) {
		for (final SkillEntry entry : this.skills) {
			if (entry.uri.equals(uri)) {
				return entry;
			}
			for (final SkillFile file : entry.files) {
				if (file.uri.equals(uri)) {
					return entry;
				}
			}
		}
		return null;
	}

	byte[] content(final String uri) {
		return this.contentByUri.get(uri);
	}

	String mimeType(final String uri) {
		return this.mimeByUri.getOrDefault(uri, "application/octet-stream");
	}

	/**
	 * Returns the direct children of a directory URI. Every skill subdirectory is
	 * enumerated as its parent's children; the root skill directory children are the
	 * skill root URIs.
	 */
	List<Map<String, Object>> directoryListing(final String dirUri) {
		final List<Map<String, Object>> children = new ArrayList<>();
		final String prefix = dirUri.endsWith("/") ? dirUri : dirUri + "/";
		for (final Map.Entry<String, String> entry : this.mimeByUri.entrySet()) {
			final String uri = entry.getKey();
			// Must be directly under the requested directory
			if (uri.startsWith(prefix) && uri.indexOf('/', prefix.length()) == -1
					&& !uri.substring(prefix.length()).isEmpty()) {
				final Map<String, Object> child = new LinkedHashMap<>();
				child.put("uri", uri);
				final String leafName = uri.substring(uri.lastIndexOf('/') + 1);
				child.put("name", leafName);
				child.put("mimeType", entry.getValue());
				children.add(child);
			}
		}
		return children;
	}

	private void loadSkills() {
		loadSkill("say-hello", "/skills/say-hello/");
		loadSkill("data-analysis", "/skills/data-analysis/");
	}

	private void loadSkill(final String name, final String prefix) {
		final String skillUri = "skill://" + name + "/SKILL.md";
		final List<String> paths = List.of(prefix + "SKILL.md", prefix + "scripts/greet.sh",
				prefix + "templates/welcome.md", prefix + "references/guide.md");

		final Map<String, Object> frontmatter = new LinkedHashMap<>();
		final List<SkillFile> files = new ArrayList<>();

		// Load SKILL.md first to extract frontmatter
		final byte[] skillMdBytes = loadBytes(prefix + "SKILL.md");
		final String skillMdText = new String(skillMdBytes, StandardCharsets.UTF_8);
		final Map<String, Object> fm = parseFrontmatter(skillMdText);
		fm.forEach(frontmatter::put);

		// Register SKILL.md and compute digest + size
		final String skMdDigest = digest(skillMdBytes);
		files.add(new SkillFile(skillUri, skMdDigest, skillMdBytes.length));
		this.contentByUri.put(skillUri, skillMdBytes);
		this.mimeByUri.put(skillUri, "text/markdown");

		// Load all other files that actually exist on classpath
		for (final String path : paths) {
			if (path.equals(prefix + "SKILL.md")) {
				continue; // already handled
			}
			final byte[] bytes = loadBytesOrNull(path);
			if (bytes == null) {
				continue;
			}
			final String relPath = path.substring(prefix.length());
			final String fileUri = "skill://" + name + "/" + relPath;
			final String fileDigest = digest(bytes);
			files.add(new SkillFile(fileUri, fileDigest, bytes.length));
			this.contentByUri.put(fileUri, bytes);
			final String mime = guessMimeType(relPath);
			this.mimeByUri.put(fileUri, mime);
		}

		// Also add directory entries for subdirectories
		this.mimeByUri.put("skill://" + name, "inode/directory");
		this.mimeByUri.put("skill://" + name + "/scripts", "inode/directory");
		this.mimeByUri.put("skill://" + name + "/templates", "inode/directory");
		this.mimeByUri.put("skill://" + name + "/references", "inode/directory");

		final SkillEntry entry = new SkillEntry(name, skillUri, frontmatter, files);
		this.skills.add(entry);
		this.byName.put(skillUri, entry);
	}

	private static Map<String, Object> parseFrontmatter(final String text) {
		final Map<String, Object> result = new LinkedHashMap<>();
		if (!text.startsWith("---")) {
			result.put("name", "unknown");
			result.put("description", "");
			return result;
		}
		final int end = text.indexOf("---", 3);
		if (end == -1) {
			result.put("name", "unknown");
			result.put("description", "");
			return result;
		}
		final String yaml = text.substring(3, end).trim();
		try {
			final Map<?, ?> parsed = YAML_MAPPER.readValue(yaml, Map.class);
			parsed.forEach((k, v) -> {
				if (k instanceof String key && v != null) {
					result.put(key, v);
				}
			});
		}
		catch (final Exception e) {
			// Fallback: simple line-based parsing
			result.put("name", "unknown");
			result.put("description", "");
			for (final String line : yaml.split("\n")) {
				final int colon = line.indexOf(':');
				if (colon == -1) {
					continue;
				}
				final String key = line.substring(0, colon).trim();
				if ("name".equals(key) || "description".equals(key)) {
					final String value = line.substring(colon + 1).trim();
					result.put(key, value.replaceAll("^\"|\"$", ""));
				}
			}
		}
		return result;
	}

	private static final YAMLMapper YAML_MAPPER = new YAMLMapper();

	private static byte[] loadBytes(final String path) {
		final InputStream in = SkillStorage.class.getResourceAsStream(path);
		if (in == null) {
			throw new RuntimeException("Resource not found: " + path);
		}
		try {
			return readAllBytes(in);
		}
		catch (final IOException e) {
			throw new RuntimeException("Failed to read: " + path, e);
		}
	}

	private static byte[] loadBytesOrNull(final String path) {
		final InputStream in = SkillStorage.class.getResourceAsStream(path);
		if (in == null) {
			return null;
		}
		try {
			return readAllBytes(in);
		}
		catch (final IOException e) {
			return null;
		}
	}

	private static byte[] readAllBytes(final InputStream in) throws IOException {
		final ByteArrayOutputStream out = new ByteArrayOutputStream();
		final byte[] buf = new byte[4096];
		int n;
		while ((n = in.read(buf)) != -1) {
			out.write(buf, 0, n);
		}
		return out.toByteArray();
	}

	private static String digest(final byte[] data) {
		try {
			final MessageDigest md = MessageDigest.getInstance("SHA-256");
			final byte[] hash = md.digest(data);
			return "sha256:" + HexFormat.of().formatHex(hash);
		}
		catch (final NoSuchAlgorithmException e) {
			throw new RuntimeException(e);
		}
	}

	private static String guessMimeType(final String path) {
		if (path.endsWith(".md")) {
			return "text/markdown";
		}
		if (path.endsWith(".sh")) {
			return "text/x-shellscript";
		}
		if (path.endsWith(".py")) {
			return "text/x-python";
		}
		if (path.endsWith(".json")) {
			return "application/json";
		}
		if (path.endsWith(".yaml") || path.endsWith(".yml")) {
			return "application/x-yaml";
		}
		return "application/octet-stream";
	}

}