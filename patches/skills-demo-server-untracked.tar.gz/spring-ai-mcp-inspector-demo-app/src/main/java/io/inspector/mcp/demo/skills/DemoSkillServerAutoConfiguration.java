package io.inspector.mcp.demo.skills;

import java.util.Map;

import jakarta.annotation.PreDestroy;

import io.inspector.mcp.core.bootstrap.InspectorBootstrapCustomizer;
import io.inspector.mcp.core.bootstrap.ServerEntry;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Auto-configuration for the SEP-2640 demo skill server. Starts a minimal MCP server
 * advertising the {@code io.modelcontextprotocol/skills} extension and registers it as a
 * pre-filled server entry in the inspector UI.
 * <p>
 * Disabled by default; use {@code demo.skills-server.enabled=true} to activate.
 */
@Configuration(proxyBeanMethods = false)
@ConditionalOnProperty(prefix = "demo.skills-server", name = "enabled", havingValue = "true", matchIfMissing = true)
public class DemoSkillServerAutoConfiguration {

	private final DemoSkillServer server;

	DemoSkillServerAutoConfiguration(@Value("${demo.skills-server.port:8082}") final int port) {
		this.server = new DemoSkillServer(port);
		this.server.start();
	}

	@PreDestroy
	void stop() {
		this.server.stop();
	}

	@Bean
	InspectorBootstrapCustomizer skillsServerEntry() {
		return bootstrap -> bootstrap.getServerEntries()
			.add(new ServerEntry("SEP-2640 Skills Server", "http://localhost:" + this.server.port(), "streamable-http",
					Map.of()));
	}

}