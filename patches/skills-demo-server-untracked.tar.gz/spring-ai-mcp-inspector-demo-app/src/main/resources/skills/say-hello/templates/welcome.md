# Welcome!

Thank you for using the MCP Inspector demo skill server. This template is a
supporting file of the `say-hello` skill and demonstrates how a skill can
reference additional Markdown resources.

## What to try next

- Ask the agent to list all available skills.
- Inquire about data-analysis skill for working with datasets.
- Check the `scripts/` directory for executable helpers.