#!/usr/bin/env bash
# A simple greeting script for the say-hello skill.
echo "Hello from the say-hello MCP skill!"
echo "Timestamp: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo "Skill version: 1.0.0"