---
name: say-hello
description: Greet a user and introduce yourself as an MCP skill server
license: MIT
metadata:
  version: 1.0.0
---

# say-hello

This skill demonstrates a minimal SEP-2640 skill. When invoked:

1. Greet the user by name (if known) or with a generic welcome.
2. Explain that this is a demo skill served over MCP using the skills extension.
3. List the supporting scripts available in `scripts/` and suggest the user
   run `greet.sh` for an interactive example.

## Usage

Ask the agent to say hello. The agent will load this skill and follow its
instructions.