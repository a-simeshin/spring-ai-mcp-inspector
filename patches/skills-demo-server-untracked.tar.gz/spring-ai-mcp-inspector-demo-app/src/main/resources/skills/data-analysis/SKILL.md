---
name: data-analysis
description: Analyze tabular datasets with summary statistics and visualisation hints
license: Apache-2.0
metadata:
  version: 2.0.0
  compatible-formats:
    - csv
    - tsv
    - json
---

# data-analysis

This skill provides a framework for analyzing structured datasets. When
invoked, the agent will:

1. Request the dataset file (CSV, TSV, or JSON).
2. Compute summary statistics: row count, column types, null counts,
   basic quantiles for numeric columns.
3. Suggest appropriate visualisations based on the data shape.

## Files

- `references/guide.md` - detailed analysis procedure and edge-case handling.

## Procedure

1. **Load the dataset** using the host's file-read tool.
2. **Inspect columns** - identify numeric, categorical, and free-text fields.
3. **Compute summaries** - mean, median, min, max for numerics; value counts
   for categoricals; null-fraction per column.
4. **Report findings** - present a concise summary and suggest next steps.