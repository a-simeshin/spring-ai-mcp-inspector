# Data Analysis Reference Guide

## Handling Edge Cases

### Missing Values
- Columns with >50% nulls should be flagged as low-confidence.
- Imputation strategies: mean for normal-distribution numerics,
  median for skewed distributions, mode for categoricals.

### Mixed-Type Columns
- If a column has both numeric and string values, report the split
  and treat the column as categorical.

### Large Datasets (>100K rows)
- For datasets exceeding 100K rows, sample 10K rows for summary
  statistics and note that results are approximate.

### Empty Results
- An empty `data` array is a valid dataset with zero rows. Report
  "empty dataset" rather than returning an error.

## Output Format

Present findings as a structured report:

```
Dataset: <name>
Rows: <N>
Columns: <M>

Numeric columns:
  <col>: mean=<val>, median=<val>, min=<val>, max=<val>, nulls=<N>

Categorical columns:
  <col>: <N> unique values, top: <val> (<count>), nulls=<N>

Suggestions:
- <chart-type> for <col1> vs <col2>
- <chart-type> for distribution of <col3>
```